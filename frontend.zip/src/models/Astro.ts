export type Astro = {
    name: string
    latitude?: number
    longitude?: number
    az?: number;
    alt?: number;
}