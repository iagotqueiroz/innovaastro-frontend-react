export const environment = {
    appUrl: "https://innovaastro-innovaastro-frontend.sifxgd.easypanel.host//",
    apiUrl: "https://innovaastro-innovaastro-backend.sifxgd.easypanel.host/"
}