export const environment = {
    appUrl: "http://localhost:5173/",
    apiUrl: "http://127.0.0.1:8000/"
}