export const environment = {
    appUrl: "http://localhost:5173/",
    apiUrl: "https://innovaastro-innovaastro-backend.sifxgd.easypanel.host/"
}